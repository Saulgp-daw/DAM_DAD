﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Windows.Media;
using Brush = System.Drawing.Brush;
using Brushes = System.Drawing.Brushes;

namespace MisComponentes
{
    public class miRadioButton : Button
    {

        public Brush outerOffColor = Brushes.Green;
        public Brush innerOffColor = Brushes.DarkGray;
        public Brush outerOnColor = Brushes.Yellow;
        public Brush innerOnColor = Brushes.White;
        public Brush outerColor;
        public Brush innerColor;
        private int xorigin = 1;
        private int yorigin = 1;
        public int innerRadious = 15;
        public int ring = 8;
        private int anchoalto;
        private int xorigin_innnercircule, yorigin_innnercircule;

        private Boolean isClicked = false;

        public miRadioButton()  
        {
            // Suscribe el manejador del evento Click al método personalizado
            this.Click += RadioButton_Click;
        }


        protected override void OnPaint(PaintEventArgs pevent)
        {

            Graphics g = pevent.Graphics;

            // Limpiamos cuadrado de fondo
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Parent.BackColor);

            outerColor = isClicked ? outerOnColor : outerOffColor;
            innerColor = isClicked ? innerOnColor : innerOffColor;

            anchoalto = 2 * (innerRadious + ring);

            // Adapto cuadrado del componente
            this.Size = new Size(anchoalto+1, anchoalto+1); 

            anchoalto = 2 * (innerRadious + ring);

            xorigin_innnercircule = ring + xorigin;
            yorigin_innnercircule = ring + yorigin;

            PathGradientBrush gradientBrush = DrawGradientEllipse(g, Brushes.Yellow, Brushes.Red, Brushes.Blue, Brushes.LimeGreen);
            g.FillEllipse(gradientBrush, 0, 0, this.Width, this.Height);
            g.FillEllipse(innerColor, xorigin_innnercircule, yorigin_innnercircule, 2 * innerRadious, 2 * innerRadious); // Circulo interior
         }

        private PathGradientBrush DrawGradientEllipse(Graphics g, Brush color1, Brush color2, Brush color3, Brush color4)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, this.Width, this.Height);

            PathGradientBrush gradientBrush = new PathGradientBrush(path);
            System.Drawing.Color[] colors = { System.Drawing.Color.FromArgb(255, 0, 255, 255) };
            gradientBrush.CenterColor = (color1 as SolidBrush).Color;
            gradientBrush.SurroundColors = colors;

            return gradientBrush;
        }

        private void RadioButton_Click(object sender, EventArgs e)
        {
            isClicked = !isClicked; // Cambia el estado cuando se hace clic
            this.Invalidate(); // Vuelve a dibujar el control cuando cambia su estado

            //MessageBox.Show("Hola","Mensage de aviso");

        }

        public Brush OuterColor
        {
            get { return outerColor; }
            set { outerColor = value; }
        }

        public Brush InnerColor
        {
            get { return innerColor; }
            set { innerColor = value; }
        }

        public int InnerRadious 
        {
            get { return innerRadious; }
            set { innerRadious = innerRadious < 1 ? 1 : value;}
        }

        public int Ring
        {
            get { return ring; }
            set { ring = ring < 1 ? 1 : value; }
        }

    }


}
