﻿using System.Drawing;
using System.Windows.Forms;

namespace MisComponentes
{
    public partial class miListBox : ListBox
    {
                
        public miListBox()
        {
            InitializeComponent();

            this.Items.Add(123);
            this.Items.Add(456);
            this.Items.Add(789);
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            e.DrawBackground();

            if (e.Index >= 0 && e.Index < Items.Count)
            {
                // Obtener el elemento en la posición actual
                object item = Items[e.Index];

                // Crear un objeto Graphics para dibujar
                using (Graphics g = e.Graphics)
                {
                    // Definir la fuente y el color del texto
                    Font font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Regular);
                    Brush brush = new SolidBrush(ForeColor);

                    // Dibujar el texto en la posición actual
                    g.DrawString(item.ToString(), font, brush, e.Bounds);
                }
            }
            base.OnDrawItem(e);
        }
    }
}
