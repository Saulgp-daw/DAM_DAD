﻿namespace testComponent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.miRadioButton1 = new MisComponentes.miRadioButton();
            this.miListBox2 = new MisComponentes.miListBox();
            this.SuspendLayout();
            // 
            // miRadioButton1
            // 
            this.miRadioButton1.InnerRadious = 20;
            this.miRadioButton1.Location = new System.Drawing.Point(101, 30);
            this.miRadioButton1.Name = "miRadioButton1";
            this.miRadioButton1.Ring = 15;
            this.miRadioButton1.Size = new System.Drawing.Size(71, 71);
            this.miRadioButton1.TabIndex = 0;
            this.miRadioButton1.Text = "miRadioButton1";
            this.miRadioButton1.UseVisualStyleBackColor = true;
            // 
            // miListBox2
            // 
            this.miListBox2.FormattingEnabled = true;
            this.miListBox2.Location = new System.Drawing.Point(466, 62);
            this.miListBox2.Name = "miListBox2";
            this.miListBox2.Size = new System.Drawing.Size(120, 95);
            this.miListBox2.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.miListBox2);
            this.Controls.Add(this.miRadioButton1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private MisComponentes.miRadioButton miRadioButton1;
        private MisComponentes.miListBox miListBox1;
        private MisComponentes.miListBox miListBox2;
    }
}

