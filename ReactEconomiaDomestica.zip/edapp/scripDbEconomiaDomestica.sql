CREATE TABLE Bancos ( 
	Id_Banco             INTEGER NOT NULL  PRIMARY KEY  ,
	NombreBanco          TEXT NOT NULL    ,
	CONSTRAINT unq_Bancos_Id_Banco UNIQUE ( Id_Banco )
 );

CREATE TABLE Periodos ( 
	Id_Periodo           INTEGER NOT NULL  PRIMARY KEY AUTOINCREMENT ,
	Periodo              TEXT NOT NULL    ,
	CONSTRAINT sqlite_autoindex_Periodos_1 UNIQUE ( Id_Periodo ),
	CONSTRAINT sqlite_autoindex_Periodos_2 UNIQUE ( Periodo )
 );

CREATE TABLE SaldosIniciales ( 
	Id_SaldoInicial      INTEGER NOT NULL  PRIMARY KEY  ,
	Fecha                TEXT NOT NULL    ,
	Banco                INTEGER NOT NULL    ,
	Importe              INTEGER NOT NULL    ,
	CONSTRAINT unq_SaldosIniciales_Id_SaldoInicial UNIQUE ( Id_SaldoInicial ),
	FOREIGN KEY ( Banco ) REFERENCES Bancos( Id_Banco )  
 );

CREATE TABLE Tipo_de_movimiento ( 
	Id_tipomovimiento    INTEGER NOT NULL  PRIMARY KEY AUTOINCREMENT ,
	Tipo_Movimiento      TEXT NOT NULL    ,
	CONSTRAINT sqlite_autoindex_Tipo_de_movimiento_1 UNIQUE ( Id_tipomovimiento ),
	CONSTRAINT sqlite_autoindex_Tipo_de_movimiento_2 UNIQUE ( Tipo_Movimiento )
 );

CREATE TABLE Previsiones ( 
	Id_Previsiones       INTEGER     ,
	Banco                INTEGER     ,
	Concepto             TEXT NOT NULL    ,
	DiaMes_de_cargo      TEXT NOT NULL    ,
	Periodo              INTEGER NOT NULL    ,
	Importe              INTEGER NOT NULL    ,
	Tipo_movimiento      INTEGER NOT NULL    ,
	CONSTRAINT sqlite_autoindex_Previsiones_2 UNIQUE ( Concepto ),
	CONSTRAINT sqlite_autoindex_Previsiones_1 UNIQUE ( Id_Previsiones ),
	CONSTRAINT pk_Previsiones UNIQUE ( Id_Previsiones  AUTOINCREMENT ),
	FOREIGN KEY ( Periodo ) REFERENCES Periodos( Id_Periodo )  ,
	FOREIGN KEY ( Tipo_movimiento ) REFERENCES Tipo_de_movimiento( Id_tipomovimiento )  ,
	FOREIGN KEY ( Banco ) REFERENCES Bancos( Id_Banco )  
 );

INSERT INTO Bancos( Id_Banco, NombreBanco ) VALUES ( 1, 'Caixa');
INSERT INTO Bancos( Id_Banco, NombreBanco ) VALUES ( 2, 'Santander');
INSERT INTO Bancos( Id_Banco, NombreBanco ) VALUES ( 3, 'BBVA');
INSERT INTO Bancos( Id_Banco, NombreBanco ) VALUES ( 4, 'ING Direct');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 1, 'Semanal');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 2, 'Quincenal');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 3, 'Mensual');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 4, 'Bimensual');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 5, 'Trimestral');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 6, 'Semestral');
INSERT INTO Periodos( Id_Periodo, Periodo ) VALUES ( 7, 'Anual');
INSERT INTO SaldosIniciales( Id_SaldoInicial, Fecha, Banco, Importe ) VALUES ( 1, '2023/01/01', 1, 1500);
INSERT INTO SaldosIniciales( Id_SaldoInicial, Fecha, Banco, Importe ) VALUES ( 2, '2023/01/01', 2, 1000);
INSERT INTO Tipo_de_movimiento( Id_tipomovimiento, Tipo_Movimiento ) VALUES ( 1, 'Ingreso');
INSERT INTO Tipo_de_movimiento( Id_tipomovimiento, Tipo_Movimiento ) VALUES ( 2, 'Gasto');
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 1, 1, 'Sueldo Ana', '01-01', 3, 1500, 1);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 2, 2, 'Sueldo Juan', '01-01', 3, 900, 1);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 3, 1, 'Hipoteca', '15-06', 3, 600, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 4, 1, 'Luz', '15-02', 4, 35, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 5, 1, 'Agua', '01-01', 4, 30, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 6, 1, 'Basura', '15-01', 3, 10, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 7, 1, 'IBI', '01-01', 7, 200, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 8, 2, 'Teléfono', '01-01', 3, 70, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 9, 2, 'ITV', '01-04', 1, 38, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 10, 2, 'Comida', '01-01', 3, 300, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 11, 2, 'Farmacia', '01-01', 5, 30, 2);
INSERT INTO Previsiones( Id_Previsiones, Banco, Concepto, DiaMes_de_cargo, Periodo, Importe, Tipo_movimiento ) VALUES ( 12, 2, 'Cine', '01-01', 3, 12, 2);