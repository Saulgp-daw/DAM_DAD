import React, { useEffect, useRef } from "react";
import "bootstrap/dist/css/bootstrap.css";
import Chart from "chart.js/auto";
import GenerateAxis from "../../utils/GenerateAxis.js";



const PrevisionChart = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  let dia = "";
  let dataArray: number[] = [];
  var labelArray: String[] = [];

  let axis = new GenerateAxis();
  //console.log(axis.getFechasProximas()); 

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext("2d");

      for (let i = 1; i <= 90; i++) {
        dia = i.toString().concat("/01");
        dataArray.push(i * 10);
        labelArray.push(dia);
      } 

      if (ctx) {
        // Si ya existe una instancia del gráfico, la destruimos
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }

        chartInstance.current = new Chart(ctx, {
          type: "line",
          data: {
            labels: labelArray,
            datasets: [
              {
                label: "# of Votes",
                data: dataArray,
                borderWidth: 1,
              },
            ],
          },
          options: {
            responsive: true,
            plugins: {
              title: {
                display: true,
                text: "Chart.js Line Chart - Cubic interpolation mode",
              },
            },
            interaction: {
              intersect: false,
            },
            scales: {
              x: {
                display: true,
                title: {
                  display: true,
                },
              },
              y: {
                display: true,
                title: {
                  display: true,
                  text: "Value",
                },
                suggestedMin: 0,
                suggestedMax: 3000,
              },
            },
          },
        });
      }
    }
  }, []);

  return (
    <div className="container">
      <div className="row">
        <div className="col-1">
          <p className="text-start fs-2 fw-semibold">Previsiones</p>
        </div>
      </div>
      <div className="row">
        <div className="col-10">
          <canvas id="myChart" ref={chartRef}></canvas>
        </div>
      </div>
    </div>
  );
};

export default PrevisionChart;
