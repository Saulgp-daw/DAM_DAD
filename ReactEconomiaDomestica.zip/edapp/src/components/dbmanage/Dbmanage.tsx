import React from 'react';
import './App.css';

function Dbmanage() {


  return (
    <div className="App">


    </div>
  );
}

export default Dbmanage;