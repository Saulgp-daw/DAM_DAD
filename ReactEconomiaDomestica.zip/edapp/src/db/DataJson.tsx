import React, { useEffect } from 'react';
import axios from 'axios';

type Prevision = {
  Id_Previsiones: number;
  Banco: string;
  Concepto: string;
  DiaMes_de_cargo: string;
  Periodo: string;
  Importe: number;
  Tipo_movimiento: number;
};

type SaldoInicial = {
  Saldo_Inicial: number;
};

const DataJson: React.FC = () => {
  useEffect(() => {
    const fetchPrevisiones = async () => {
      try {
        const result = await axios.get<Prevision[]>('http://localhost:3030/Previsiones');
        //console.log('Previsiones:', result.data);
      } catch (error) {
        console.error('Error al cargar las previsiones:', error);
      }
    };

    const fetchSaldoInicial = async () => {
      try {
        const result = await axios.get<SaldoInicial[]>('http://localhost:3030/SaldoInicial');
        //console.log('Saldo Inicial:', result.data);
      } catch (error) {
        console.error('Error al cargar el saldo inicial:', error);
      }
    };

    fetchPrevisiones();
    fetchSaldoInicial();
  }, []);

  return <div>Comprobando los datos...</div>;
};

export default DataJson;
