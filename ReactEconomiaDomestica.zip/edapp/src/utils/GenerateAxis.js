import axios from "axios";

class GenerateAxis {
  fechaActual;
  fechasProximas;
  saldoInicial;
  previsiones;
  datosPrevisiones;
  axis;
  arrayAuxPrevisiones;
  arrayPeriodos = [
    { Mensual: 1 },
    { Bimensual: 2 },
    { Trimestral: 3 },
    { Semetral: 6 },
  ];

  constructor() {
    this.fechaActual = new Date();
    this.init();
  }

  async init() {
    await this.fetchSaldoInicial();
    await this.fetchPrevisiones();
    this.fechasProximas = this.generarFechasProximas();
    console.log("Previsiones: " + JSON.stringify(this.fechasProximas));
    this.datosPrevisiones = this.guardarDatosPrevisiones();
    this.axis = this.generarSaldosProximos();
    /*
    for (let prevision of this.datosPrevisiones) {
      console.log("DiaMes_de_cargo: " + prevision.DiaMes_de_cargo);
      console.log("Periodo: " + prevision.Periodo);
      console.log("Importe " + prevision.Importe);
      console.log("---------------------------------------");
    }
    */
  }

  async fetchSaldoInicial() {
    try {
      const result = await axios.get("http://localhost:3030/SaldoInicial");
      this.saldoInicial = result.data[0].Saldo_Inicial;
      //console.log("Saldo inicial: " + this.saldoInicial);
    } catch (error) {
      console.error("Error al cargar el saldo inicial:", error);
    }
  }

  async fetchPrevisiones() {
    try {
      const result = await axios.get("http://localhost:3030/Previsiones");
      this.previsiones = result.data;
      //console.log("Previsiones: " + JSON.stringify(this.previsiones));
      this.datosPrevisiones = this.guardarDatosPrevisiones();
    } catch (error) {
      console.error("Error al cargar las previsiones:", error);
    }
  }

  guardarDatosPrevisiones() {
    let datos = [];
    //console.log("Previsiones: " + JSON.stringify(this.previsiones));
    for (let prevision of this.previsiones) {
      
      /*
      let fechas = this.generarFechasdeDato(
        prevision.DiaMes_de_cargo,
        prevision.Periodo
      );
*/
      //console.log("generarFechasdeDato: " + fechas);

      let dato = {
        DiaMes_de_cargo: prevision.DiaMes_de_cargo,
        Periodo: prevision.Periodo,
        Importe: prevision.Importe,
        Tipo_movimiento: prevision.Tipo_movimiento,
      };
      datos.push(dato);
    }

    return datos;
  }

  generarFechasdeDato(fecha, periodo) {
    // Convertir la fecha a un objeto Date
    let partes = fecha.split("-");
    let fechaInicio = new Date();
    fechaInicio.setDate(parseInt(partes[0]));
    fechaInicio.setMonth(parseInt(partes[1]) - 1);

    // Definir el incremento según el periodo
    let incremento;

    switch (periodo) {
      case "Mensual":
        incremento = 1;
        break;
      case "Bimensual":
        incremento = 2;
        break;
      case "Trimestral":
        incremento = 3;
        break;
      case "Semestral":
        incremento = 6;
        break;
      default:
        return "Periodo no válido";
    }

    // Generar las fechas
    let fechas = [];
    let fechaActual = new Date();
 

    while (fechaInicio <= fechaActual.setMonth(fechaActual.getMonth() + 3)) {
      fechas.push(fechaInicio.getDate() + "/" + (fechaInicio.getMonth() + 1));
      fechaInicio.setMonth(fechaInicio.getMonth() + incremento);
    }

    return fechas;
  }

  generarFechasProximas() {
    let fechas = [];
    for (let i = 0; i < 90; i++) {
      let fecha = new Date(this.fechaActual);
      fecha.setDate(this.fechaActual.getDate() + i);
      let dia = ("0" + fecha.getDate()).slice(-2); // Asegura que el día siempre tenga dos dígitos.
      let mes = ("0" + (fecha.getMonth() + 1)).slice(-2); // Asegura que el mes siempre tenga dos dígitos.
      fechas.push({ fecha: `${dia}/${mes}`, valor: "" });
    }
    //console.log("generarFechasProximas_fechas: " + fechas);
    return fechas;
  }

  generarSaldosProximos() {
    this.arrayAuxPrevisiones = this.generarArrayAuxPrevisiones();
    //PRIMER PASE
    // Recorro previsiones
    // De datos tomo el mes de DiaMes_de_cargo y compruevo que esté en los tres meses vista
    // Si está continuo:
    // Me sitúo en la fecha previsiones formado por el dia de DiaMes_de_cargo y el primer mes de la prevision
    // Al saldoIncial le sumo o resto el Importe datos según sea el tipo_movimiento
    // y lo inserto en this.fechasProximas.

    //SIGUIENTES PASES

    return this.fechasProximas;
  }

  generarArrayAuxPrevisiones() {
    // Obtén el mes actual y los dos meses siguientes
    let fechaActual = new Date();
    let mesActual = fechaActual.getMonth() + 1;
    let mesSiguiente = mesActual + 1 > 12 ? 1 : mesActual + 1;
    let mesSiguienteSiguiente = mesSiguiente + 1 > 12 ? 1 : mesSiguiente + 1;

    // Asegúrate de que los meses siempre tengan dos dígitos
    mesActual = ("0" + mesActual).slice(-2);
    mesSiguiente = ("0" + mesSiguiente).slice(-2);
    mesSiguienteSiguiente = ("0" + mesSiguienteSiguiente).slice(-2);

    let nuevoArray = this.datosPrevisiones
      .filter((dato) => {
        // Extrae el mes del campo DiaMes_de_cargo
        let mes = dato.DiaMes_de_cargo.split("-")[1];

        // Comprueba si el mes está en el rango deseado
        return (
          mes === mesActual ||
          mes === mesSiguiente ||
          mes === mesSiguienteSiguiente
        );
      })
      .map((dato) => {
        // Añade el campo Saldo al objeto
        return { ...dato, Saldo: dato.Importe };
      });

    //console.log(nuevoArray);

    return nuevoArray;
  }

  getFechasProximas() {
    return this.fechasProximas;
  }
}

export default GenerateAxis;
