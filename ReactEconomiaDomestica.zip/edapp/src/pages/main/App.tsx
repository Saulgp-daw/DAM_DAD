import React from "react";
import Navigationbar from "../../components/navbar/Navigationbar";
import "./App.css";
import PrevisionChart from "../../components/previsionchart/PrevisionChart";
import DataJson from "../../db/DataJson"


function App() {
  return (
    <div className="App">
        <Navigationbar />
        <hr/>
        <PrevisionChart />
        <hr/>
        <DataJson />

    </div>
  );
}
export default App;
