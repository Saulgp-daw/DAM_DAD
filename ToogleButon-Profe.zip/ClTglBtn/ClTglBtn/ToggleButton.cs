﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace CLTglBtn
{
    public class ToggleButton : Button
    {

        private Color onBackColor = Color.MediumSlateBlue;
        private Color onToggleColor = Color.WhiteSmoke;
        private Color offBackColor = Color.Gray;
        private Color offToggleColor = Color.Gainsboro;
        private bool solidStyle = true;
        private bool isToggled = false;

        // Constructor
        public ToggleButton()
        {
            // Suscribe el manejador del evento Click al método personalizado
            this.Click += ToggleButton_Click;
        }

        // Propiedad para cambiar el color de fondo
        public Color ChangeOnBackColor
        {
            get { return this.onBackColor; }
            set { this.onBackColor = value; }
        }

        public Color ChangeOffBackColor
        {
            get { return this.offBackColor; }
            set { this.offBackColor = value; }
        }

        public Boolean ChangeSolidStyle
        {
            get { return this.solidStyle; }
            set { this.solidStyle = value; }
        }


        //Methods
        private GraphicsPath GetFigurePath()
        {
            int arcSize = Height - 1;
            Rectangle leftArc = new Rectangle(0, 0, arcSize, arcSize);
            Rectangle rightArc = new Rectangle(Width - arcSize - 2, 0, arcSize, arcSize);
            
            GraphicsPath path = new GraphicsPath();
            
            path.AddArc(leftArc, 90, 180);
            path.AddArc(rightArc, 270, 180);
            path.CloseFigure();          

            return path;
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            // Definir el tamaño del interruptor.
            int toggleSize = Height - 5;

            // Configurar el modo de suavizado y limpiar el fondo.
            pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            pevent.Graphics.Clear(Parent.BackColor);

            // Definir los colores de fondo y del interruptor.
            Color backColor = solidStyle ? (isToggled ? onBackColor : offBackColor) : (isToggled ? offBackColor : onBackColor);
            Color toggleColor = isToggled ? onToggleColor : offToggleColor;

            // Crear un pincel para el fondo con el color de fondo.
            using (var backgroundBrush = new SolidBrush(backColor))
            {
                // Crear un pincel para el interruptor con el color del interruptor.
                using (var toggleBrush = new SolidBrush(toggleColor))
                {
                    // Rellenar la figura con el color de fondo.
                    pevent.Graphics.FillPath(backgroundBrush, GetFigurePath());

                    // Rellenar el círculo del interruptor.
                    // Si el interruptor está activado, se dibuja a la derecha.
                    // Si no está activado, se dibuja a la izquierda.
                    int toggleXPosition = isToggled ? Width - Height + 1 : 2;
                    pevent.Graphics.FillEllipse(toggleBrush, toggleXPosition, 2, toggleSize, toggleSize);
                }
            }
        }


        // Manejador del evento Click
        private void ToggleButton_Click(object sender, EventArgs e)
        {
            isToggled = !isToggled; // Cambia el estado cuando se hace clic
            this.Invalidate(); // Vuelve a dibujar el control cuando cambia su estado
        }
    }
}
